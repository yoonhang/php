<?php

echo 'product.php';